package ProjetoJava_Final_Rui;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.ComponentOrientation;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.Component;
import javax.swing.Box;


public class POS {
	 public static double TOTAL=0;
	 public static double TAXA=0;
	 public static double DISCOUNT=0;
	 public static double Saida=0;
// Variavel para teclas de multiplicação - para permitir multiplicar o produto escolhido pela tecla escolhia 1,2,3,4,5...
	 public static int Multiplicador=1;  
//	IVAS	 
	 public static double IVA_A=6;  //não usado
	 public static double IVA_B=13; //aguas naturais e comidas
	 public static double IVA_C=23; //bebidas
// Valor Produtos dos Botoes nao personalizaveis
	 public static double AguaSemGas=1.50;
	 public static double AguaComGas=1.50;
	 public static double AguaSabores=2;
	 public static double SumoLata=2;
	 public static double Imperial=1.5;
	 public static double Cerveja=2;
	 public static double Digestivos=3;
	 public static double Gin=6;
	 public static double Hamburger=5;
	 public static double Tosta=3.5;
	 public static double TostaMista=5;
	 public static double Cafe=0.8;
	 public static String Pagamento=null;
	 
//********personalizaçoes de botoes****
	 double artigo1 = 0;
	 double artigo2 = 0;
	 double artigo3 = 0;
	 double artigo4 = 0;
	 String nomeproduto = null;
	 String precoproduto= null;
	 int IVA = 0;
	 int clickCount = 0;
	 

 
//**********************************************************************************
	private JFrame frame;
	private JTextField texNOME;
	private JTextField textNIF;
	private JTable table;
	private JTable table2;
	private JTextField textinserenomeproduto;
	private JTextField textinserepreco;	
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField textFieldIDProduto;
	DefaultTableModel modelo2 = new DefaultTableModel();	
	DefaultTableModel modelo = new DefaultTableModel();
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					POS window = new POS();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public POS() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
// ****************************** Jpaneis **********************************************	
		
		JPanel Artigos = new JPanel();
		Artigos.setBackground(SystemColor.textHighlight);
		frame.getContentPane().add(Artigos, "name_906173501991700");
		Artigos.setLayout(null);
		
		JPanel Fatura = new JPanel();
		Fatura.setBackground(SystemColor.textHighlight);
		frame.getContentPane().add(Fatura, "name_906176457247500");
		
		JPanel Dados = new JPanel();
		frame.getContentPane().add(Dados, "name_1172539014465500");
		Dados.setLayout(null);
		
		JPanel InsereStock = new JPanel();
		InsereStock.setBackground(SystemColor.textHighlight);
		frame.getContentPane().add(InsereStock, "name_1311226731948400");
		InsereStock.setLayout(null);
		
		JPanel Papel = new JPanel();
		Papel.setBackground(Color.WHITE);
		frame.getContentPane().add(Papel, "name_101554815966500");
		Papel.setLayout(null);
		
// ************* Text Fiels && JLabels	*******************************
		
		textFieldIDProduto = new JTextField();
		textFieldIDProduto.setBackground(SystemColor.info);
		textFieldIDProduto.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textFieldIDProduto.setBounds(269, 85, 103, 33);
		InsereStock.add(textFieldIDProduto);
		textFieldIDProduto.setColumns(10);
		
		JLabel lblIdDoProduto = new JLabel("ID do Produto");
		lblIdDoProduto.setForeground(Color.WHITE);
		lblIdDoProduto.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblIdDoProduto.setBounds(63, 85, 196, 33);
		InsereStock.add(lblIdDoProduto);
		
		JLabel lblNewLabel_3 = new JLabel("ID do produto inserida automáticamente");
		lblNewLabel_3.setForeground(new Color(255, 255, 255));
		lblNewLabel_3.setBounds(382, 73, 250, 33);
		InsereStock.add(lblNewLabel_3);
		
		JLabel lblNewLabel_5 = new JLabel("Preencher apenas em caso de edição");
		lblNewLabel_5.setForeground(new Color(255, 255, 255));
		lblNewLabel_5.setBounds(382, 96, 250, 21);
		InsereStock.add(lblNewLabel_5);
		
		JTextArea textAreaProdutos = new JTextArea();
		textAreaProdutos.setRows(15);
		textAreaProdutos.setBounds(10, 42, 147, 400);
		Artigos.add(textAreaProdutos);
		
		JTextArea textAreaValor = new JTextArea();
		textAreaValor.setFont(new Font("Monospaced", Font.PLAIN, 13));
		textAreaValor.setRows(15);
		textAreaValor.setBounds(155, 42, 70, 400);
		Artigos.add(textAreaValor);
		
		JLabel lblNewLabel_4 = new JLabel("POS Rui Amaral");
		lblNewLabel_4.setBounds(10, 540, 132, 13);
		lblNewLabel_4.setForeground(Color.WHITE);
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		Fatura.add(lblNewLabel_4);

		JLabel lblNewLabel = new JLabel("POS Rui Amaral");
		lblNewLabel.setForeground(SystemColor.text);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setBounds(10, 540, 132, 13);
		Artigos.add(lblNewLabel);
		
		JLabel lblGRSI = new JLabel("GRSI 8492 - Projecto Final");
		lblGRSI.setForeground(Color.WHITE);
		lblGRSI.setBounds(286, 19, 240, 13);
		Artigos.add(lblGRSI);
		
		JLabel lblSubtotal = new JLabel("Subtotal");
		lblSubtotal.setForeground(Color.WHITE);
		lblSubtotal.setBounds(10, 452, 76, 13);
		Artigos.add(lblSubtotal);
		
		JLabel lblTaxa = new JLabel("IVA");
		lblTaxa.setForeground(Color.WHITE);
		lblTaxa.setBounds(10, 469, 45, 13);
		Artigos.add(lblTaxa);
		
		JLabel label = new JLabel("New label");
		label.setBounds(138, 452, 19, 0);
		Artigos.add(label);
		
		JLabel lblSubtotal_1 = new JLabel("0.0");
		lblSubtotal_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSubtotal_1.setForeground(Color.WHITE);
		lblSubtotal_1.setBounds(181, 452, 45, 13);
		Artigos.add(lblSubtotal_1);
		
		JLabel lblTotal_Iva = new JLabel("0.0");
		lblTotal_Iva.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTotal_Iva.setForeground(Color.WHITE);
		lblTotal_Iva.setBounds(181, 469, 45, 13);
		Artigos.add(lblTotal_Iva);
		
		JLabel lblTOTAL = new JLabel("0.0");
		lblTOTAL.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTOTAL.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTOTAL.setForeground(Color.WHITE);
		lblTOTAL.setBounds(150, 496, 76, 13);
		Artigos.add(lblTOTAL);
		
		JLabel lblTotal = new JLabel("Total");
		lblTotal.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTotal.setForeground(Color.WHITE);
		lblTotal.setBounds(10, 496, 101, 13);
		Artigos.add(lblTotal);
		
		textinserenomeproduto = new JTextField();
		textinserenomeproduto.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textinserenomeproduto.setBounds(269, 127, 337, 33);
		InsereStock.add(textinserenomeproduto);
		textinserenomeproduto.setColumns(10);
		
		textinserepreco = new JTextField();
		textinserepreco.setFont(new Font("Tahoma", Font.PLAIN, 16));
		textinserepreco.setColumns(10);
		textinserepreco.setBounds(269, 170, 103, 33);
		InsereStock.add(textinserepreco);
	
		JLabel lblNomeProduto = new JLabel("Nome do Produto");
		lblNomeProduto.setForeground(new Color(255, 255, 255));
		lblNomeProduto.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNomeProduto.setBounds(63, 127, 196, 33);
		InsereStock.add(lblNomeProduto);
		
		JLabel lblPrecoProduto = new JLabel("Preço Venda");
		lblPrecoProduto.setForeground(new Color(255, 255, 255));
		lblPrecoProduto.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPrecoProduto.setBounds(63, 170, 137, 33);
		InsereStock.add(lblPrecoProduto);
		
		JLabel lblGRSI_1 = new JLabel("GRSI 8492 - Projecto Final");
		lblGRSI_1.setForeground(Color.WHITE);
		lblGRSI_1.setBounds(10, 20, 240, 13);
		Fatura.add(lblGRSI_1);
		
		JLabel lblNewLabel_1 = new JLabel("Dados de Faturação");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setBounds(10, 32, 766, 42);
		Dados.add(lblNewLabel_1);
		
		JLabel lblNOME = new JLabel("NOME:");
		lblNOME.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNOME.setBounds(23, 130, 110, 45);
		Dados.add(lblNOME);
		
		texNOME = new JTextField();
		texNOME.setBounds(79, 132, 697, 45);
		Dados.add(texNOME);
		texNOME.setColumns(10);
		
		JLabel lblNIF = new JLabel("N.I.F.:");
		lblNIF.setFont(new Font("Tahoma", Font.PLAIN, 16));
		lblNIF.setBounds(23, 244, 110, 45);
		Dados.add(lblNIF);
		
		textNIF = new JTextField();
		textNIF.setColumns(10);
		textNIF.setBounds(79, 244, 697, 45);
		Dados.add(textNIF);
		
		JLabel lblNewLabel_2 = new JLabel("Coloque um ponto caso não pretenda Nome");
		lblNewLabel_2.setBounds(79, 185, 697, 13);
		Dados.add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("Coloque um ponto caso não pretenda NIF");
		lblNewLabel_2_1.setBounds(79, 299, 697, 13);
		Dados.add(lblNewLabel_2_1);
		
		JLabel lblIva = new JLabel("IVA");
		lblIva.setForeground(Color.WHITE);
		lblIva.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblIva.setBounds(63, 255, 97, 33);
		InsereStock.add(lblIva);
		
		JLabel lblGereStock = new JLabel("Gestão de Stocks");
		lblGereStock.setForeground(SystemColor.text);
		lblGereStock.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblGereStock.setBounds(63, 31, 591, 25);
		InsereStock.add(lblGereStock);
		
		//************* Fatura em Papel *****************

		JLabel lblNomeEmpresa = new JLabel("Cafeteria Amaral");
		lblNomeEmpresa.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNomeEmpresa.setBounds(240, 47, 348, 13);
		Papel.add(lblNomeEmpresa);
		JLabel lblDesignacaoComercial = new JLabel("Rui Amaral & Filhos S.A.");
		lblDesignacaoComercial.setBounds(240, 65, 160, 13);
		Papel.add(lblDesignacaoComercial);
		JLabel lblMorada = new JLabel("Rua do Sol Posto, nº 1");
		lblMorada.setBounds(240, 88, 160, 13);
		Papel.add(lblMorada);
		JLabel lblCPostal = new JLabel("1111-000 Quinta do Sol");
		lblCPostal.setBounds(240, 100, 160, 13);
		Papel.add(lblCPostal);
		JLabel lblTLM = new JLabel("Tlm: 931234567");
		lblTLM.setBounds(240, 111, 160, 13);
		Papel.add(lblTLM);
		JLabel lblNIFEmpresa = new JLabel("NIF: 505123456");
		lblNIFEmpresa.setBounds(240, 123, 160, 13);
		Papel.add(lblNIFEmpresa);
		JLabel lblNewLabel_6 = new JLabel("Fatura Simplificada");
		lblNewLabel_6.setBounds(240, 170, 160, 13);
		Papel.add(lblNewLabel_6);
		JLabel lblDataFatura = new JLabel("Data");
		lblDataFatura.setHorizontalAlignment(SwingConstants.LEFT);
		lblDataFatura.setBounds(240, 193, 88, 13);
		Papel.add(lblDataFatura);
		JLabel lblDiversos = new JLabel("Diversos");
		lblDiversos.setBounds(240, 311, 69, 13);
		Papel.add(lblDiversos);
		JLabel lblIvaPapel1 = new JLabel("IVA");
		lblIvaPapel1.setHorizontalAlignment(SwingConstants.CENTER);
		lblIvaPapel1.setBounds(319, 276, 45, 13);
		Papel.add(lblIvaPapel1);
		JLabel lblTotalFatura = new JLabel("Total");
		lblTotalFatura.setHorizontalAlignment(SwingConstants.CENTER);
		lblTotalFatura.setBounds(405, 276, 45, 13);
		Papel.add(lblTotalFatura);
		JLabel lblArtigosPapel = new JLabel("Artigos");
		lblArtigosPapel.setBounds(240, 276, 45, 13);
		Papel.add(lblArtigosPapel);


		JLabel lblRecebeIVA = new JLabel("00.00");
		lblRecebeIVA.setHorizontalAlignment(SwingConstants.CENTER);
		lblRecebeIVA.setBounds(319, 311, 45, 13);
		Papel.add(lblRecebeIVA);

		JLabel lblRecebeTotalSemIva = new JLabel("00.00" + " €");
		lblRecebeTotalSemIva.setHorizontalAlignment(SwingConstants.CENTER);
		lblRecebeTotalSemIva.setBounds(405, 311, 45, 13);
		Papel.add(lblRecebeTotalSemIva);
		JLabel lblNewLabel_7 = new JLabel("TOTAL:");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_7.setBounds(338, 382, 45, 13);
		Papel.add(lblNewLabel_7);
		JLabel lblRecebeTotal = new JLabel("00.00"+" €");
		lblRecebeTotal.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRecebeTotal.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblRecebeTotal.setBounds(393, 382, 57, 13);
		Papel.add(lblRecebeTotal);
		JLabel lblNewLabel_9 = new JLabel("Obrigado e volte sempre!!");
		lblNewLabel_9.setBounds(240, 451, 160, 13);
		Papel.add(lblNewLabel_9);
		JLabel lblNewLabel_10 = new JLabel("Pago em:");
		lblNewLabel_10.setBounds(240, 358, 88, 13);
		Papel.add(lblNewLabel_10);
		JLabel lblRecebeTipoPagamento = new JLabel("tipo pgt");
		lblRecebeTipoPagamento.setHorizontalAlignment(SwingConstants.CENTER);
		lblRecebeTipoPagamento.setBounds(405, 358, 45, 13);
		Papel.add(lblRecebeTipoPagamento);
		JButton btnVolta_2 = new JButton("Voltar");
		btnVolta_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Papel.setVisible(false);
				Artigos.setVisible(true);
				
				
			}
		});
		btnVolta_2.setBounds(661, 15, 115, 45);
		Papel.add(btnVolta_2);
		JLabel lblNewLabel_11 = new JLabel("Nome Cliente:");
		lblNewLabel_11.setBounds(240, 216, 88, 13);
		Papel.add(lblNewLabel_11);
		JLabel lblRecebeNome = new JLabel("RecebeNome");
		lblRecebeNome.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRecebeNome.setBounds(319, 216, 136, 13);
		Papel.add(lblRecebeNome);

		JLabel lblNIFCliente = new JLabel("NIF:");
		lblNIFCliente.setBounds(240, 227, 45, 13);
		Papel.add(lblNIFCliente);

		JLabel lblRecebeNIF = new JLabel("RecebeNIF");
		lblRecebeNIF.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRecebeNIF.setBounds(319, 227, 131, 13);
		Papel.add(lblRecebeNIF);

		JLabel lblRecebeNrFatura = new JLabel("00000");
		lblRecebeNrFatura.setHorizontalAlignment(SwingConstants.RIGHT);
		lblRecebeNrFatura.setBounds(387, 170, 63, 13);
		Papel.add(lblRecebeNrFatura);

		JLabel lblNewLabel_8 = new JLabel("-----------------------------------------------------");
		lblNewLabel_8.setBounds(240, 345, 215, 13);
		Papel.add(lblNewLabel_8);
		JLabel lblNewLabel_8_1 = new JLabel("-----------------------------------------------------");
		lblNewLabel_8_1.setBounds(240, 288, 215, 13);
		Papel.add(lblNewLabel_8_1);
		JLabel lblNewLabel_8_1_1 = new JLabel("-----------------------------------------------------");
		lblNewLabel_8_1_1.setBounds(240, 265, 212, 13);
		Papel.add(lblNewLabel_8_1_1);
		JLabel lblNewLabel_8_2 = new JLabel("-----------------------------------------------------");
		lblNewLabel_8_2.setBounds(240, 369, 215, 13);
		Papel.add(lblNewLabel_8_2);
		JLabel lblNewLabel_8_3 = new JLabel("-----------------------------------------------------");
		lblNewLabel_8_3.setBounds(240, 147, 215, 13);
		Papel.add(lblNewLabel_8_3);		
		
		
		
//*********************** Criar modelos das tabelas *************************
//***faturas***		
JScrollPane scrollPane = new JScrollPane();
scrollPane.setBounds(10, 92, 766, 392);
Fatura.add(scrollPane);
modelo.addColumn("id");
modelo.addColumn("Nome");
modelo.addColumn("NIF");
modelo.addColumn("IVA");
modelo.addColumn("Total_Fatura");
modelo.addColumn("Data_Fatura");
modelo.addColumn("Pagamento");
table = new JTable(modelo);
scrollPane.setViewportView(table);

//***Stocks***
JScrollPane scrollPane_1 = new JScrollPane();
scrollPane_1.setBounds(10, 311, 766, 225);
InsereStock.add(scrollPane_1);
modelo2.addColumn("id");
modelo2.addColumn("Nome");
modelo2.addColumn("Preço");
modelo2.addColumn("IVA");
table2 = new JTable(modelo2);
scrollPane_1.setViewportView(table2);
								
		
// *************** Botão Voltar Menu Fatura **********		
		
JButton btnVolta = new JButton("Voltar");
btnVolta.setBounds(661, 20, 115, 45);
btnVolta.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		Fatura.setVisible(false);
		Artigos.setVisible(true);
		}
});
Fatura.setLayout(null);
Fatura.add(btnVolta);
		
//************* Botao Multiplicador 1 **************	
//Ao carregar no botao com o nr 1 ele coloca esse valor na variavel para posteriormente multiplicar pelo artigo				
JButton btn1 = new JButton("1");
btn1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	 Multiplicador=1;
	 }
});
btn1.setBounds(236, 42, 40, 40);
Artigos.add(btn1);
	
//************* Botao Multiplicador 2 **************

JButton btn2 = new JButton("2");
btn2.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=2;
	}
});
btn2.setBounds(236, 82, 40, 40);
Artigos.add(btn2);

//************* Botao Multiplicador 3 **************
		
JButton btn3 = new JButton("3");
btn3.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=3;
	}
});
	btn3.setBounds(236, 122, 40, 40);
	Artigos.add(btn3);

//************* Botao Multiplicador 4 **************
	
JButton btn4 = new JButton("4");
btn4.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=4;
	}
});
btn4.setBounds(236, 162, 40, 40);
Artigos.add(btn4);

//************* Botao Multiplicador 5 **************	

JButton btn5 = new JButton("5");
btn5.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=5;
	}
});
btn5.setBounds(236, 202, 40, 40);
Artigos.add(btn5);
//************* Botao Multiplicador 6 **************		
JButton btn6 = new JButton("6");
btn6.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=6;
	}
});
btn6.setBounds(236, 242, 40, 40);
Artigos.add(btn6);
//************* Botao Multiplicador 7 **************		
JButton btn7 = new JButton("7");
btn7.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=7;
	}
});
btn7.setBounds(236, 282, 40, 40);
Artigos.add(btn7);
//************* Botao Multiplicador 8 **************	~
		
JButton btn8 = new JButton("8");
btn8.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=8;
	}
});
btn8.setBounds(236, 322, 40, 40);
Artigos.add(btn8);

//************* Botao Multiplicador 9 **************
		
JButton btn9 = new JButton("9");
btn9.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=9;
	}
});
btn9.setBounds(236, 362, 40, 40);
Artigos.add(btn9);
		
//************* Botao Limpa Multiplicador **************	
//em caso de engano ao pressionar um botao multiplicador, o botao C coloca a variavel a 1		
JButton btnC = new JButton("C");
btnC.setFont(new Font("Tahoma", Font.PLAIN, 10));
btnC.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	Multiplicador=1;
	}
});
btnC.setBounds(236, 402, 40, 40);
Artigos.add(btnC);


		
//************ Labels Data Sistema Automática no JPane Artigos e JPane Fatura ***************

JLabel lblData = new JLabel("Data");
lblData.setForeground(Color.WHITE);
lblData.setBounds(616, 19, 65, 13);
Artigos.add(lblData);
		
// Cria um objeto DateTimeFormatter usando o método ofPattern e passa como argumento
// a string "dd/MM/yyyy", para definir o padrão de formatação da data. 		
DateTimeFormatter FormatoDaData = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		
// retorna a data atual do sistema na forma de um objeto LocalDate.
LocalDate dataAtual = LocalDate.now();
		
//formata a data atual (dataAtual)no formato especificado ("dd-MM-yyyy") e armazena o resultado
//numa string chamada dataFormatada.		
String dataFormatada = FormatoDaData.format(dataAtual);
		
// Imprime a String na Label
lblData.setText(dataFormatada);

JLabel lblData_1 = new JLabel("Data1");
lblData_1.setForeground(Color.WHITE);
lblData_1.setBounds(10, 43, 65, 13);
Fatura.add(lblData_1);
lblData_1.setText(dataFormatada);
		
		
//************* Botao não personalizavel Agua Sem Gas **************

JButton btnAguaSemGas = new JButton("Agua s/gas\r\n");		//nome do botão e texto a apresentar 
btnAguaSemGas.addActionListener(new ActionListener() {		//"escuta" quando o botao é pressionado e executa o codigo seguinte
	public void actionPerformed(ActionEvent e) {
	textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT); //Informa que a TextAreaValor será alinhada á dir. (irá receber valores posteriormente)
	textAreaProdutos.append(" "+Multiplicador +" Agua s/gas\n");  // Coloca o valor da variavel Multiplicador e o texto "Agua s...." na TextAreaProdutos
	textAreaValor.append("Eur " +AguaSemGas*Multiplicador +" \n");  // Multiplica 2 variaveis e coloca o valor do produto na TextAreaValor 
			        
	TOTAL=TOTAL+(AguaSemGas*Multiplicador);  //Calcula e acumula o valor do produto consoante o multiplicador escolhido
	TAXA = TAXA + (AguaSemGas*IVA_B/100*Multiplicador); //Calcula e acumula o valor do IVA tendo em conta o multiplicador escolhido
			    
	lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA)); // Calcula e coloca o valor do produto sem VA na label subtotal
	lblTotal_Iva.setText(String.format("%.2f",TAXA));// coloca o valor IVA na label subtotal
	lblTOTAL.setText(String.format("%.2f", TOTAL));  //Coloca o valor do produto com IVA na label TOTAL
			      
	Multiplicador=1;  //Reeinicia o Multiplicador para começar a 1 no proximo produto
	}
});
btnAguaSemGas.setBounds(286, 84, 115, 75);
Artigos.add(btnAguaSemGas);

//************* Botao não personalizavel Agua Com Gas **************

JButton btnAguaComGas = new JButton("Agua c/gas");
btnAguaComGas.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	textAreaProdutos.append(" "+Multiplicador +" Agua c/gas\n");
	textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
	textAreaValor.append("Eur " +AguaComGas*Multiplicador +" \n");
	TOTAL=TOTAL+(AguaComGas*Multiplicador);
	TAXA = TAXA + (AguaComGas*IVA_B/100*Multiplicador);
	lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
	lblTotal_Iva.setText(String.format("%.2f",TAXA));
	lblTOTAL.setText(String.format("%.2f", TOTAL));
	Multiplicador=1;
	}
});
btnAguaComGas.setBounds(286, 169, 115, 75);
Artigos.add(btnAguaComGas);

//************* Botao não personalizavel Agua Com Sabores **************		
JButton btnAguaSabores = new JButton("Agua Sabores");
btnAguaSabores.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Agua Sabores\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +AguaSabores*Multiplicador +" \n");
		TOTAL=TOTAL+(AguaSabores*Multiplicador);
		TAXA = TAXA + (AguaSabores*IVA_C/100*Multiplicador);		        
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));        
		lblTotal_Iva.setText(String.format("%.2f",TAXA));		        
		lblTOTAL.setText(String.format("%.2f", TOTAL));				
		Multiplicador=1;
		}
	});
btnAguaSabores.setBounds(286, 254, 115, 75);
Artigos.add(btnAguaSabores);
		
//************* Botao não personalizavel Sumo Lata **************
		
JButton btnSumoLata = new JButton("Sumo Lata");
btnSumoLata.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Sumo Lata\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +SumoLata*Multiplicador +" \n");
		TOTAL=TOTAL+(SumoLata*Multiplicador);
		TAXA = TAXA + (SumoLata*IVA_C/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnSumoLata.setBounds(411, 84, 115, 75);
Artigos.add(btnSumoLata);	
		
//************* Botao não personalizavel Imperial **************	
		
JButton btnImperial = new JButton("Imperial");
btnImperial.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {				
		textAreaProdutos.append(" "+Multiplicador +" Imperial\n");						
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);		        
		textAreaValor.append("Eur " +Imperial*Multiplicador +" \n");				
		TOTAL=TOTAL+(Imperial*Multiplicador);		       
		TAXA = TAXA + (Imperial*IVA_C/100*Multiplicador);	        
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));		        
		lblTotal_Iva.setText(String.format("%.2f",TAXA));		        
		lblTOTAL.setText(String.format("%.2f", TOTAL));				
		Multiplicador=1;
		}
	});
btnImperial.setBounds(411, 169, 115, 75);
Artigos.add(btnImperial);

//************* Botao não personalizavel Cerveja Garrafa **************	

JButton btnCervejaGarrafa = new JButton("Cerveja Garrafa");
btnCervejaGarrafa.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Cerveja Garrafa\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +Cerveja*Multiplicador +" \n");
		TOTAL=TOTAL+(Cerveja*Multiplicador);
		TAXA = TAXA + (Cerveja*IVA_C/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnCervejaGarrafa.setBounds(411, 254, 115, 75);
Artigos.add(btnCervejaGarrafa);

//************* Botao não personalizavel Digestivos **************

JButton btnDigestivos = new JButton("Digestivos");
btnDigestivos.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Digestivos\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +Digestivos*Multiplicador +" \n");
		TOTAL=TOTAL+(Digestivos*Multiplicador);
		TAXA = TAXA + (Digestivos*IVA_C/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnDigestivos.setBounds(536, 84, 115, 75);
Artigos.add(btnDigestivos);
		
//************* Botao não personalizavel GIN **************

JButton btnGin = new JButton("Gin");
btnGin.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Gin\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +Gin*Multiplicador +" \n");
		TOTAL=TOTAL+(Gin*Multiplicador);
		TAXA = TAXA + (Gin*IVA_C/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnGin.setBounds(536, 169, 115, 75);
Artigos.add(btnGin);
	
//************* Botao não personalizavel Hamburguer **************

JButton btnHamburguer = new JButton("Hamburger");
btnHamburguer.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Hamburger\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +Hamburger*Multiplicador +" \n");
		TOTAL=TOTAL+(Hamburger*Multiplicador);
		TAXA = TAXA + (Hamburger*IVA_B/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnHamburguer.setBounds(536, 254, 115, 75);
Artigos.add(btnHamburguer);

//************* Botao não personalizavel Tosta **************

JButton btnTosta = new JButton("Tosta");
btnTosta.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Tosta\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +Tosta*Multiplicador +" \n");
		TOTAL=TOTAL+(Tosta*Multiplicador);
		TAXA = TAXA + (Tosta*IVA_B/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnTosta.setBounds(661, 84, 115, 75);
Artigos.add(btnTosta);

//************* Botao não personalizavel Tosta Mista **************
		
JButton btnTostaMista = new JButton("Tosta Mista");
btnTostaMista.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Tosta Mista\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +TostaMista*Multiplicador +" \n");
		TOTAL=TOTAL+(TostaMista*Multiplicador);
		TAXA = TAXA + (TostaMista*IVA_B/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnTostaMista.setBounds(661, 169, 115, 75);
Artigos.add(btnTostaMista);
		
//************* Botao não personalizavel Cafe **************

JButton btnCafe = new JButton("Cafe");
btnCafe.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" "+Multiplicador +" Café\n");		
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append("Eur " +Cafe*Multiplicador +" \n");
		TOTAL=TOTAL+(Cafe*Multiplicador);
		TAXA = TAXA + (Cafe*IVA_B/100*Multiplicador);
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		}
	});
btnCafe.setBounds(661, 254, 115, 75);
Artigos.add(btnCafe);
		
//************* Botao Ver Faturas **************		
		
JButton btnconsulta = new JButton("Ver Faturas");
btnconsulta.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {		
		Artigos.setVisible(false);
		Fatura.setVisible(true);
		texNOME.setText(null);
		textNIF.setText(null);
		jdbccafe cafe = new jdbccafe();
		cafe.conectar();	
		DefaultTableModel modelo = cafe.exibirFaturas(null);
		table.setModel(modelo);
		cafe.logout();
        
		}
	});
btnconsulta.setBounds(10, 15, 101, 21);
Artigos.add(btnconsulta);
	
//**************** Botão VOID - Elimina os valores introduzidos para reeiniciar a introdução ******************	

JButton btnVoid = new JButton("Void");
btnVoid.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.setText(null);
		textAreaValor.setText(null);
		TOTAL=0;
		TAXA=0;
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;		
		}
	});
btnVoid.setHorizontalTextPosition(SwingConstants.CENTER);
btnVoid.setFont(new Font("Tahoma", Font.BOLD, 12));
btnVoid.setForeground(Color.WHITE);
btnVoid.setBackground(Color.RED);
btnVoid.setBounds(711, 509, 65, 44);
Artigos.add(btnVoid);
		
//************* botao desconto - dá 10% de desconto sobre o total da fatura	*****************	
		
JButton btDiscount = new JButton("Discount");
btDiscount.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		textAreaProdutos.append(" DISCOUNT 10% \n");
		DISCOUNT=TOTAL;
		TOTAL=TOTAL-(TOTAL*0.1);
		TAXA=TAXA-(TAXA*0.1);
		DISCOUNT=TOTAL-DISCOUNT;
		textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
		textAreaValor.append(String.format("%.2f", DISCOUNT)+ " \n");
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Multiplicador=1;
		DISCOUNT=0;
		}
	});
btDiscount.setHorizontalTextPosition(SwingConstants.CENTER);
btDiscount.setFont(new Font("Tahoma", Font.BOLD, 12));
btDiscount.setForeground(Color.WHITE);
btDiscount.setBackground(new Color(255, 165, 0));
btDiscount.setBounds(616, 509, 85, 44);
Artigos.add(btDiscount);
		
//************* Pagamento Cash **************	
		
JButton btnCash = new JButton("Cash");
btnCash.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {				
		Pagamento = "Cash";
		Artigos.setVisible(false);	
		Dados.setVisible(true);
		}
	});
btnCash.setHorizontalTextPosition(SwingConstants.CENTER);
btnCash.setFont(new Font("Tahoma", Font.BOLD, 12));
btnCash.setForeground(Color.WHITE);
btnCash.setBackground(new Color(34, 139, 34));
btnCash.setBounds(236, 496, 85, 57);
Artigos.add(btnCash);		

//************* Pagamento Multibanco **************

JButton btnMultibanco = new JButton("Multibanco");
btnMultibanco.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		Pagamento = "Multi";
		Artigos.setVisible(false);	
		Dados.setVisible(true);
		}
	});
btnMultibanco.setHorizontalTextPosition(SwingConstants.CENTER);
btnMultibanco.setFont(new Font("Tahoma", Font.BOLD, 12));
btnMultibanco.setForeground(Color.WHITE);
btnMultibanco.setBackground(new Color(0, 204, 255));
btnMultibanco.setBounds(331, 509, 85, 44);
Artigos.add(btnMultibanco);

//************* Pagamento Visa **************		
		
JButton btnVisa = new JButton("Visa");
btnVisa.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		Pagamento = "Visa";
		Artigos.setVisible(false);	
		Dados.setVisible(true);
		}	
});
btnVisa.setHorizontalTextPosition(SwingConstants.CENTER);
btnVisa.setFont(new Font("Tahoma", Font.BOLD, 12));
btnVisa.setForeground(Color.WHITE);
btnVisa.setBackground(new Color(0, 204, 255));
btnVisa.setBounds(426, 509, 85, 44);
Artigos.add(btnVisa);
		
//************* Pagamento Mastercard **************	
		
JButton btnMastercard = new JButton("Mastercard");
btnMastercard.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		Pagamento = "Master";
	Artigos.setVisible(false);	
	Dados.setVisible(true);
	}
});
btnMastercard.setHorizontalTextPosition(SwingConstants.CENTER);
btnMastercard.setFont(new Font("Tahoma", Font.BOLD, 12));
btnMastercard.setForeground(Color.WHITE);
btnMastercard.setBackground(new Color(0, 204, 255));
btnMastercard.setBounds(521, 509, 85, 44);
Artigos.add(btnMastercard);
				
//****************Botao Confirmar - Confirma e insere fatura na Base Dados ***************		
		
JButton btnNewButton = new JButton("Confirmar");
btnNewButton.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		jdbccafe cafe = new jdbccafe();
		cafe.conectar();
		if(cafe.estaconectado()){
			String IVA = lblTotal_Iva.getText();
			String Total_Fatura=lblTOTAL.getText();
			String Data_Fatura=lblData.getText();
			String NIF = textNIF.getText();
			String Nome = texNOME.getText();				
			cafe.inserirfatura(Nome,NIF,IVA,Total_Fatura,Data_Fatura,Pagamento);//colocar aqui o NOME DOS CAMPOS DA SUA bd
			cafe.logout();
			}else {
				System.out.println("Nao foi possivel ligar a BD");
				}
		textAreaProdutos.setText(null);
		textAreaValor.setText(null);
		TOTAL=0;
		TAXA=0;
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		Dados.setVisible(false);
		Artigos.setVisible(true);				
		JOptionPane.showMessageDialog(frame, "Fatura Registada");	
		}
	});
btnNewButton.setBounds(344, 457, 115, 52);
Dados.add(btnNewButton);

//****************Botao Anular (volta atras) ***************		

JButton btnAnular = new JButton("Anular");
btnAnular.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		Dados.setVisible(false);
		Artigos.setVisible(true);
		}
	});
btnAnular.setBounds(661, 19, 115, 55);
Dados.add(btnAnular);

//************* Botao Pesquisar ****************
//*********** Tambem altera a cor do texto da linha que tiver um Void ********************
JButton btnPesquisar = new JButton("Pesquisar");
btnPesquisar.setBounds(220, 508, 115, 45);
btnPesquisar.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		jdbccafe cafe = new jdbccafe();
        cafe.conectar();
        if (cafe.estaconectado()) {
          
               
                String input = JOptionPane.showInputDialog(null, "Digite o ID da fatura a ser exibida:");
                DefaultTableModel modelo = cafe.exibirFaturas(input);
        		table.setModel(modelo);
        		cafe.logout();
        }
	}
        }); 
Fatura.add(btnPesquisar);
		
// ************ Botão Imprimir **************		
		JButton btnImprimir = new JButton("Imprimir");
		btnImprimir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 Fatura.setVisible(false);
			        Papel.setVisible(true);
				String idFatura = JOptionPane.showInputDialog(null, "Digite o ID da fatura:");  // pede o nr da fatura a consultar

		        try {
		            jdbccafe cafe = new jdbccafe();
		            cafe.conectar();

		            String sql = "SELECT * FROM fatura WHERE id = " + idFatura;  // cria a query com o nr escolhido pelo utilizador
		            ResultSet resultSet = cafe.statement.executeQuery(sql);	// executa a query na base de dados

		            if (resultSet.next()) {				// se a consulta tiver resultados, armazena os valores em diferentes strings
		                String id = resultSet.getString("id");		// armazena o resultado da coluna "id" da base de dados na string id
		                String nome = resultSet.getString("Nome");  // armazena o resultado da coluna "Nome" da base de dados na string nome
		                String nif = resultSet.getString("NIF");  // armazena o resultado da coluna "NIF" da base de dados na string nif
		                String iva = resultSet.getString("IVA");
		                String totalFatura = resultSet.getString("Total_Fatura");
		                String dataFatura = resultSet.getString("Data_Fatura");
		                String pagamento = resultSet.getString("Pagamento");

		               
		                double ivasemvirgula = Double.parseDouble(iva.replace(",", ".")); // Remove a vírgula e substitui por ponto
		                double totalFaturasemvirgula = Double.parseDouble(totalFatura.replace(",", ".")); // Remover a vírgula....
		                
		                // Atualiza as JLabels com os valores obtidos
		                    lblRecebeNrFatura.setText(id);
		                    lblRecebeNome.setText(nome);
		                    lblRecebeNIF.setText(nif);
		                    lblRecebeIVA.setText(iva);
		                    lblRecebeTotal.setText(totalFatura);
		                    lblDataFatura.setText(dataFatura);
		                    lblRecebeTipoPagamento.setText(pagamento);

		                    // Realizar a operação de subtração para retornar um valor total sem iva
		                    double totalSemIva = totalFaturasemvirgula - ivasemvirgula;

		                    // Atualiza a JLabel com o valor calculado
		                    String totalSemIva2 = String.format("%.2f", totalSemIva);
		                    lblRecebeTotalSemIva.setText(String.valueOf(totalSemIva2));
		               
		            } else {
		                // Fatura não encontrada, exibir mensagem de erro ou tratar de outra forma
		            }

		            resultSet.close();
		            cafe.logout(); // Fechar a conexão após o uso do ResultSet
		        } catch (SQLException ex) {
		            ex.printStackTrace();
		        }
		    }
		});
		
		btnImprimir.setBounds(641, 508, 115, 45);
		Fatura.add(btnImprimir);
		
		
//************* Botão Nota Credito **************	
		
JButton btnVoidFatura = new JButton("Nota Credito");
btnVoidFatura.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {         
		jdbccafe cafe = new jdbccafe();
	    cafe.conectar();
        if (cafe.estaconectado()) {
            try {                                   
                String id = JOptionPane.showInputDialog(null, "Digite o ID da fatura a anular:");             
                int option = JOptionPane.showConfirmDialog(null, "Tem certeza que deseja anular a fatura selecionada?", "Confirmação", JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    cafe.voidfatura(id);
                }
                DefaultTableModel modelo = cafe.exibirFaturas(null);
        		table.setModel(modelo);
        		cafe.logout();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }       
});
btnVoidFatura.setBounds(358, 508, 115, 45);
Fatura.add(btnVoidFatura);

//************* Botão Logout **************	
		
JButton btnLogout = new JButton("Logout");
btnLogout.setForeground(Color.WHITE);
btnLogout.setBackground(Color.RED);
btnLogout.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		int saida = JOptionPane.showOptionDialog(null, "Pretende Fazer Logout?", "Confirmação",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Sim", "Não"}, "Não");
		if (saida == JOptionPane.YES_OPTION) {
			System.exit(0);
			}
		}
	});
btnLogout.setBounds(691, 15, 85, 21);
Artigos.add(btnLogout);
		
		
		
//****************** PERSONALIZAÇÕES DE CLIENTE *********************		
		
//**************** Botao personalizar *****************************		
JButton btnPersonalizar = new JButton("Personalizar");		//nome e descrição do botao
btnPersonalizar.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {		//escuta se for pressionado
		if (artigo1==0)	{								//se não tiver personalização anterior (valor da variavel a zero) executa o codigo
			int saida = JOptionPane.showOptionDialog(null, "Pretende Personalizar o Botão?", "Confirmação",		//confirma se pretende a personalizaçao
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Sim", "Não"}, "Não");
			if (saida == JOptionPane.NO_OPTION) {			
				return;}   	
			else  {String inputid = JOptionPane.showInputDialog(null, "Digite o id do produto:");		//pede a introduçao do id do artigo a personalizar			
						
			if (inputid == null) {							// se o utilizador nao digitar id ou clicar em "cancelar" a execução do codigo é cancelada
			 	return;} 				
			int Botao1Produto = Integer.parseInt(inputid);		//converte a string "input" que contem "id do produto" em um inteiro "Botao1Produto "
			int Botao1Preco=Botao1Produto;						//Atribui o valor de Botao1Produto à variável Botao1Preco
			jdbccafe cafe = new jdbccafe();
			cafe.conectar();								//Chama o método conectar no objeto cafe para estabelecer uma conexão com o banco de dados
			if (cafe.estaconectado()) {
				nomeproduto = cafe.stock(Botao1Produto);	//Chama o método stock(Botao1Produto)para obter o nome do produto com base no ID do produto.
															//O nome do produto é armazenado na variável nomeproduto.
				
				btnPersonalizar.setText(nomeproduto);		//Altera o texto do botão btnPersonalizar com o valor de nomeproduto
				double precoproduto = cafe.stock2(Botao1Preco);		//Chama o método stock2(Botao1Preco) para obter o preço do produto
				artigo1 = precoproduto;						//atribuí à variável artigo1 o valor de precoproduto
				textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
				textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
				textAreaValor.append("Eur " +artigo1*Multiplicador +" \n");
				TOTAL=TOTAL+(artigo1*Multiplicador);
				TAXA = TAXA + (artigo1*IVA_B/100*Multiplicador);
				lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
				lblTotal_Iva.setText(String.format("%.2f",TAXA));
				lblTOTAL.setText(String.format("%.2f", TOTAL));
				Multiplicador=1;
				}	
			else {System.out.println("Não foi possível conectar à BD");}
			}
			}
		else {				//caso o botao já tenha um valor definido na variavel artigo1, ele ja nao se personaliza e executa o codigo como um botao normal
			textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
			textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
			textAreaValor.append("Eur " +artigo1*Multiplicador +" \n");
			TOTAL=TOTAL+(artigo1*Multiplicador);
			TAXA = TAXA + (artigo1*IVA_B/100*Multiplicador);
			lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
			lblTotal_Iva.setText(String.format("%.2f",TAXA));
			lblTOTAL.setText(String.format("%.2f", TOTAL));
			Multiplicador=1;}
		}	
});
btnPersonalizar.setBounds(661, 339, 115, 75);
Artigos.add(btnPersonalizar);
		

// *************** Inicio botao personalizado 1 ***************	
		
		JButton btnPersonalizar_1 = new JButton("Personalizar");
		btnPersonalizar_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			if (artigo2==0)	{
				int saida = JOptionPane.showOptionDialog(null, "Pretende Personalizar o Botão?", "Confirmação",
				JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Sim", "Não"}, "Não");
				if (saida == JOptionPane.NO_OPTION) {
					return;}   
		
				else  {String inputid = JOptionPane.showInputDialog(null, "Digite o id do produto:");
					if (inputid == null) { 
				 	return;} 
				
				
				int Botao1Produto = Integer.parseInt(inputid);
				int Botao1Preco=Botao1Produto;
					
				jdbccafe cafe = new jdbccafe();
				cafe.conectar();
				if (cafe.estaconectado()) {
				nomeproduto = cafe.stock(Botao1Produto);
				btnPersonalizar_1.setText(nomeproduto);
		        double precoproduto = cafe.stock2(Botao1Preco);
		        artigo2 = precoproduto;
		        textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
				textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
				textAreaValor.append("Eur " +artigo2*Multiplicador +" \n");
				TOTAL=TOTAL+(artigo2*Multiplicador);
				TAXA = TAXA + (artigo2*IVA_B/100*Multiplicador);
				lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
				lblTotal_Iva.setText(String.format("%.2f",TAXA));
				lblTOTAL.setText(String.format("%.2f", TOTAL));
				Multiplicador=1;
			    }	
				else {
			    System.out.println("Não foi possível conectar à BD");}
					}
				}
			else {
				textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
				textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
				textAreaValor.append("Eur " +artigo2*Multiplicador +" \n");
				TOTAL=TOTAL+(artigo2*Multiplicador);
				TAXA = TAXA + (artigo2*IVA_B/100*Multiplicador);
				lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
				lblTotal_Iva.setText(String.format("%.2f",TAXA));
				lblTOTAL.setText(String.format("%.2f", TOTAL));
				Multiplicador=1;}		
			}
		});
		btnPersonalizar_1.setBounds(536, 339, 115, 75);
		Artigos.add(btnPersonalizar_1);
		
		
//****************** fim botao personalizar 1 *******************
		
// *************** Inicio botao personalizar 2 ***************
		
		JButton btnPersonalizar_2 = new JButton("Personalizar");
		btnPersonalizar_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (artigo3==0)	{
					int saida = JOptionPane.showOptionDialog(null, "Pretende Personalizar o Botão?", "Confirmação",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Sim", "Não"}, "Não");
					if (saida == JOptionPane.NO_OPTION) {
						return;}   
			
					else  {String inputid = JOptionPane.showInputDialog(null, "Digite o id do produto:");
						if (inputid == null) { 
					 	return;} 
					
					
					int Botao1Produto = Integer.parseInt(inputid);
					int Botao1Preco=Botao1Produto;
						
					jdbccafe cafe = new jdbccafe();
					cafe.conectar();
					if (cafe.estaconectado()) {
					nomeproduto = cafe.stock(Botao1Produto);
					btnPersonalizar_2.setText(nomeproduto);
			        double precoproduto = cafe.stock2(Botao1Preco);
			        artigo3 = precoproduto;
			        textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
					textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
					textAreaValor.append("Eur " +artigo3*Multiplicador +" \n");
					TOTAL=TOTAL+(artigo3*Multiplicador);
					TAXA = TAXA + (artigo3*IVA_B/100*Multiplicador);
					lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
					lblTotal_Iva.setText(String.format("%.2f",TAXA));
					lblTOTAL.setText(String.format("%.2f", TOTAL));
					Multiplicador=1;
				    }	
					else {
				    System.out.println("Não foi possível conectar à BD");}
						}
					}
			else {
					textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
					textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
					textAreaValor.append("Eur " +artigo3*Multiplicador +" \n");
					TOTAL=TOTAL+(artigo3*Multiplicador);
					TAXA = TAXA + (artigo3*IVA_B/100*Multiplicador);
					lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
					lblTotal_Iva.setText(String.format("%.2f",TAXA));
					lblTOTAL.setText(String.format("%.2f", TOTAL));
					Multiplicador=1;}		
				}
			});
		btnPersonalizar_2.setBounds(411, 339, 115, 75);
		Artigos.add(btnPersonalizar_2);		
		
//****************** fim botao personalizar 2 *******************
		
// *************** Inicio botao personalizar 3 ***************		
		
JButton btnPersonalizar_3 = new JButton("Personalizar");
btnPersonalizar_3.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		if (artigo4==0)	{
			int saida = JOptionPane.showOptionDialog(null, "Pretende Personalizar o Botão?", "Confirmação",
					JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, new Object[] {"Sim", "Não"}, "Não");
			if (saida == JOptionPane.NO_OPTION) {
				return;}   			
			else  {String inputid = JOptionPane.showInputDialog(null, "Digite o id do produto:");
			if (inputid == null) { 
				return;} 										
			int Botao1Produto = Integer.parseInt(inputid);
			int Botao1Preco=Botao1Produto;						
			jdbccafe cafe = new jdbccafe();
			cafe.conectar();
			if (cafe.estaconectado()) {
				nomeproduto = cafe.stock(Botao1Produto);
				btnPersonalizar_3.setText(nomeproduto);
				double precoproduto = cafe.stock2(Botao1Preco);
				artigo4 = precoproduto;
				textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
				textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
				textAreaValor.append("Eur " +artigo4*Multiplicador +" \n");
				TOTAL=TOTAL+(artigo4*Multiplicador);
				TAXA = TAXA + (artigo4*IVA_B/100*Multiplicador);
				lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
				lblTotal_Iva.setText(String.format("%.2f",TAXA));
				lblTOTAL.setText(String.format("%.2f", TOTAL));
				Multiplicador=1;
				}	
			else {
				System.out.println("Não foi possível conectar à BD");}
			}
			}
		else {
			textAreaProdutos.append(" "+Multiplicador + " " +nomeproduto +"\n");		
			textAreaValor.setComponentOrientation(ComponentOrientation.RIGHT_TO_LEFT);
			textAreaValor.append("Eur " +artigo4*Multiplicador +" \n");
			TOTAL=TOTAL+(artigo4*Multiplicador);
			TAXA = TAXA + (artigo4*IVA_B/100*Multiplicador);
			lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
			lblTotal_Iva.setText(String.format("%.2f",TAXA));
			lblTOTAL.setText(String.format("%.2f", TOTAL));
			Multiplicador=1;}	
		}
	});
btnPersonalizar_3.setBounds(286, 339, 115, 75);
Artigos.add(btnPersonalizar_3);	

// ***** 3 clicks na barra e reeinicia os botoes personalizaveis **********		
		
JButton btnBarrCafetaria = new JButton("Cafeteria Amaral");
btnBarrCafetaria.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		clickCount++;
		if (clickCount == 3) {
			int dialogResult = JOptionPane.showConfirmDialog(null, "Deseja executar a ação?", "Confirmação", JOptionPane.YES_NO_OPTION);
			if (dialogResult == JOptionPane.YES_OPTION) {
				nomeproduto="Personalizar";
				artigo1=0;artigo2=0;artigo3=0;artigo4=0;
				btnPersonalizar.setText(nomeproduto);
				btnPersonalizar_1.setText(nomeproduto);
				btnPersonalizar_2.setText(nomeproduto);
				btnPersonalizar_3.setText(nomeproduto);
				JOptionPane.showMessageDialog(null, "Botões formatados!");
				}
			clickCount = 0;
			}
		}
	});
btnBarrCafetaria.setFont(new Font("Tahoma", Font.BOLD, 14));
btnBarrCafetaria.setHorizontalTextPosition(SwingConstants.CENTER);
btnBarrCafetaria.setForeground(Color.WHITE);
btnBarrCafetaria.setBackground(Color.ORANGE);
btnBarrCafetaria.setBounds(286, 42, 490, 32);
Artigos.add(btnBarrCafetaria);	
				

//*************** Botoes IVA *****************				
				
JRadioButton rdbtnIVAA = new JRadioButton("IVA A (" + IVA_A + "%)");
rdbtnIVAA.setForeground(new Color(255, 255, 255));
rdbtnIVAA.setBackground(SystemColor.textHighlight);
rdbtnIVAA.setFont(new Font("Tahoma", Font.BOLD, 16));
buttonGroup.add(rdbtnIVAA);
rdbtnIVAA.setBounds(182, 261, 151, 21);
InsereStock.add(rdbtnIVAA);
				
JRadioButton rdbtnIVAB = new JRadioButton("IVA B (" + IVA_B + "%)");
rdbtnIVAB.setForeground(new Color(255, 255, 255));
rdbtnIVAB.setBackground(SystemColor.textHighlight);
rdbtnIVAB.setFont(new Font("Tahoma", Font.BOLD, 16));
buttonGroup.add(rdbtnIVAB);
rdbtnIVAB.setBounds(349, 261, 152, 21);
InsereStock.add(rdbtnIVAB);
				
JRadioButton rdbtnIVAC = new JRadioButton("IVA C (" + IVA_C + "%)");
rdbtnIVAC.setForeground(new Color(255, 255, 255));
rdbtnIVAC.setBackground(SystemColor.textHighlight);
rdbtnIVAC.setFont(new Font("Tahoma", Font.BOLD, 16));
buttonGroup.add(rdbtnIVAC);
rdbtnIVAC.setBounds(503, 261, 151, 21);
InsereStock.add(rdbtnIVAC);
					
//************** Botao inserir stocks**************************				
				
JButton btnInserirNovo = new JButton("Inserir");
btnInserirNovo.setBackground(new Color(144, 238, 144));
btnInserirNovo.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		jdbccafe cafe = new jdbccafe();
		cafe.conectar();
		modelo.setRowCount(0);
		if(cafe.estaconectado()){
			double IVA=0;
			if (rdbtnIVAA.isSelected()) {IVA=IVA_A;}
			if (rdbtnIVAB.isSelected()) {IVA=IVA_B;}
			if (rdbtnIVAC.isSelected()) {IVA=IVA_C;}
			String nomeproduto = textinserenomeproduto.getText();
			String precoproduto=textinserepreco.getText();
			cafe.inserirprodutos(nomeproduto,precoproduto,IVA);//colocar aqui o NOME DOS CAMPOS da BaseDados
			cafe.logout();} 
		else {System.out.println("Nao foi possivel ligar a BD");}
		textAreaProdutos.setText(null);
		textAreaValor.setText(null);
		TOTAL=0;
		TAXA=0;
		lblSubtotal_1.setText(String.format("%.2f",TOTAL-TAXA));
		lblTotal_Iva.setText(String.format("%.2f",TAXA));
		lblTOTAL.setText(String.format("%.2f", TOTAL));
		
		Dados.setVisible(false);
		Fatura.setVisible(false);
		InsereStock.setVisible(false);
		Artigos.setVisible(true);
		JOptionPane.showMessageDialog(frame, "Artigo Registado");}
	});
btnInserirNovo.setBounds(661, 139, 115, 45);
InsereStock.add(btnInserirNovo);
			
				
//************* botao editar stocks*****************						
				
JButton btnEditar = new JButton("Editar");
btnEditar.setBackground(new Color(250, 250, 210));
btnEditar.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		jdbccafe cafe = new jdbccafe();
		cafe.conectar();
		modelo2.setRowCount(0);
		if (cafe.estaconectado()) {
			try {
				double IVA = 0;
                if (rdbtnIVAA.isSelected()) {IVA = IVA_A;}
                if (rdbtnIVAB.isSelected()) {IVA = IVA_B;}
                if (rdbtnIVAC.isSelected()) {IVA = IVA_C;}
                String id = textFieldIDProduto.getText();
                String nomeproduto = textinserenomeproduto.getText();
                String precoproduto = textinserepreco.getText();
                cafe.conectar();              
                cafe.updateFun(id, nomeproduto, precoproduto, IVA);
                JOptionPane.showMessageDialog(frame, "Produto Atualizado");
// chamada do método exibirTabela para atualizar a tabela
                
                modelo2 = cafe.exibirTabela();
                table2.setModel(modelo2);               
                cafe.logout();
                } catch (NumberFormatException ex) {
                	JOptionPane.showMessageDialog(frame, "O ID deve ser um número inteiro.");
                } catch (Exception ex) {
                	JOptionPane.showMessageDialog(frame, "Erro ao atualizar o produto: " + ex.getMessage());
                	} finally {
                		cafe.logout();
                		}
			} else {System.out.println("Não foi possível conectar ao BD");}
// limpar valores
		textFieldIDProduto.setText(null);
        textinserenomeproduto.setText(null);
        textinserepreco.setText(null);       
        buttonGroup.clearSelection();
    }
});
btnEditar.setBounds(661, 191, 115, 45);
InsereStock.add(btnEditar);
				
				
//************* botao visualizar stocks*****************		
				
JButton btnVizualizar = new JButton("Visualizar");
btnVizualizar.setBackground(new Color(224, 255, 255));
btnVizualizar.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	modelo2.setRowCount(0);
    jdbccafe cafe = new jdbccafe();
	cafe.conectar();
	if (cafe.estaconectado()) {
	try {
		String sql = "SELECT * FROM stocks";
		cafe.resultset = cafe.statement.executeQuery(sql);
		while (cafe.resultset.next()) {
			Object[] registo1 = new Object[5];
			registo1[0] = cafe.resultset.getInt("id");
			registo1[1] = cafe.resultset.getString("nomeproduto");
			registo1[2] = cafe.resultset.getString("precoproduto");
			registo1[3] = cafe.resultset.getString("IVA");
			modelo2.addRow(registo1);}
		}
	catch (NumberFormatException | SQLException f) {
		f.printStackTrace();}
	finally {cafe.logout();}
	}
	else {System.out.println("Nao foi possivel ligar a BD");}						
}
});
btnVizualizar.setBounds(661, 84, 115, 45);
InsereStock.add(btnVizualizar);
				
				
//************* botao eliminar stocks*****************	
// o botao mostra os artigos antes de pedir qual o artigo a eliminar, e atualiza a tabela de seguida *****
				
JButton btnEliminar = new JButton("Eliminar"); 
btnEliminar.setBackground(new Color(240, 128, 128));
btnEliminar.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e)  {
		try {
		    jdbccafe cafe = new jdbccafe();
		    cafe.conectar();
		    modelo2.setRowCount(0);		// limpa os valores da tabela apresentada
		    if (cafe.estaconectado()) {
		        String sql = "SELECT * FROM stocks";	//executa uma query para mostrar uma tabela atualizada
		        try (ResultSet resultSet = cafe.statement.executeQuery(sql)) {
		            while (resultSet.next()) {
		                Object[] registo1 = new Object[5];
		                registo1[0] = resultSet.getInt("id");
		                registo1[1] = resultSet.getString("nomeproduto");
		                registo1[2] = resultSet.getString("precoproduto");
		                registo1[3] = resultSet.getString("IVA");
		                modelo2.addRow(registo1);
		            }
		        } catch (SQLException f) {f.printStackTrace();}
// os seguintes passos pedem o numero do artigo a ser eliminado e alerta caso não exista uma introdução 
		        try {
		            String id = JOptionPane.showInputDialog(null, "Digite o ID do artigo a eliminar:");
		            if (id == null || id.isEmpty()) {
		                JOptionPane.showMessageDialog(frame, "É necessário introduzir um id");
		                return;
		            }
//com o numero do artigo a eliminar, chama o metodo "deleteFun" que elimina o produto da base de dados		            
		            cafe.deleteFun(Integer.parseInt(id));
		            JOptionPane.showMessageDialog(frame, "Artigo Removido");
		            modelo2.setRowCount(0); // limpa a tabela anteriormente apresentada
		            
// atualiza novamente a tabela apresentada ao utilizador		            
			        try (ResultSet resultSet = cafe.statement.executeQuery(sql)) {
			            while (resultSet.next()) {
			                Object[] registo1 = new Object[5];
			                registo1[0] = resultSet.getInt("id");
			                registo1[1] = resultSet.getString("nomeproduto");
			                registo1[2] = resultSet.getString("precoproduto");
			                registo1[3] = resultSet.getString("IVA");
			                modelo2.addRow(registo1);
			            }
			        }
		        } catch (NumberFormatException ex) { //identifica se o numero é inteiro
		            JOptionPane.showMessageDialog(frame, "O ID deve ser um número inteiro.");
		        }
		        cafe.logout();
		    } else {
		        System.out.println("Não foi possível conectar ao BD");
		    }
		} catch (Exception f) {
		    f.printStackTrace();
		}
	}
});		
btnEliminar.setBounds(661, 245, 115, 45);
InsereStock.add(btnEliminar);
				
		
//******************Botao Voltar ***************		
JButton btnVolta_1 = new JButton("Voltar");
btnVolta_1.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		InsereStock.setVisible(false);
		Artigos.setVisible(true);
	}
});
btnVolta_1.setBounds(661, 25, 115, 45);
InsereStock.add(btnVolta_1);


				
//******************Botao Produtos ***************
	
JButton btnProdutos = new JButton("Produtos");
btnProdutos.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		Artigos.setVisible(false);
		InsereStock.setVisible(true);
	}
});
btnProdutos.setBounds(121, 15, 104, 21);
Artigos.add(btnProdutos);







	}	
}
