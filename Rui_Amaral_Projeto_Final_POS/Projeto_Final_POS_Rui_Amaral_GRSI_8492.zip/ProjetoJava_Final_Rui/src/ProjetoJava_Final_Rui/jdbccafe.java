package ProjetoJava_Final_Rui;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class jdbccafe {
	static Connection connection = null;
	Statement statement = null; //gere as consultas
	ResultSet resultset = null; //armazena as informacoes das consultas
	
		  
//**************** Conecta ao driver do XAMPP ************	
public void conectar()
	{
	String JDBC_DRIVER = "com.mysql.jdbc.Driver";//caminho do driver que foi adicionado
	String DB_URL = "jdbc:mysql://localhost:3306/cafe";//porta padrao que o mysql usa
	String user = "root";
	String pass = "";
	try {
		Class.forName("com.mysql.jdbc.Driver");
		this.connection=  (Connection) DriverManager.getConnection(DB_URL, user, pass);
		this.statement=  (Statement) this.connection.createStatement();
		}catch (Exception e) //armazena informação sobre erros
		   {System.out.println("erro: " + e.getMessage());} //retorna uma msg com o erro existente 		   
	}

//*************** metodo que retorna um valor booleano ****************
//*************se conseguiu conectar então é diferente de null, dá resultado true ***************

public boolean estaconectado() {
	if(this.connection!=null) {
		return true;
	}else { //senao nao conseguiu connectar entao continua null, entra no false
		return false;}
}


//**********************logout com mensagem***************
public void logout() {
	try {
		this.connection.close();
		}catch(Exception e) {				
		 System.out.println("erro: " + e.getMessage());}			
}


//**********************insere dados de fatura na base de dados ******************
public void inserirfatura(String Nome, String NIF, String IVA,String Total_Fatura, String Data_Fatura, String Pagamento)
{
	try{
		String query = "INSERT INTO fatura (Nome,NIF,IVA,Total_Fatura,Data_Fatura,Pagamento) VALUES ('" + Nome + "','" + NIF + "','" + IVA + "','" + Total_Fatura + "','" + Data_Fatura + "','" + Pagamento + "')";
		this.statement.executeUpdate(query);
	
	}catch(Exception e) {
		
			   System.out.println("erro: " + e.getMessage());
		   }
}

//*******************Elimina dados da base de dados (atraves de ID) ****************

public void deleteFun(int id) {
try {
String query = "DELETE FROM stocks WHERE id =" + id;
this.statement.executeUpdate(query);
//JOptionPane.showMessageDialog(null, "Fatura removida com sucesso!");
} catch (Exception e) {
System.out.println("erro: " + e.getMessage());
}
}


//*******************Usar a base de dados como fonte de valores e produtos*********************
//** Caso seja necessário o cliente programar os botoes, permite ir buscar qualquer valor    **
//** á base de dados e colocá-lo numa variavel para uso. Por exemplo o botao que está        **
//** como Personalizar, corresponderia ao id 1 da tabela stocks e iria buscar o valor da       **
//** coluna 1 (nome do produto) e da coluna 2 (preço do produto) e colocaria o nome no botao **
//** com o nome do artigo no menu do utilizador e o respetivo valor numa variavel B		     **
//*********************************************************************************************

public String stock(int Botao1Produto) {
    try {
    	String sql = "SELECT nomeproduto FROM stocks WHERE id=" + Botao1Produto; 
        ResultSet rs = statement.executeQuery(sql);
        if (rs.next()) {
            String nomeprod = rs.getString("nomeproduto");
            return nomeprod ;
        } else {
        	JOptionPane.showMessageDialog(null, "Nenhum produto encontrado");
            //System.out.println("Nenhum produto encontrado");
        }
        rs.close();
    } catch (SQLException e) {
        System.out.println("Botão não Configurado: " + e.getMessage());
    } 
    return null;}

//**************************************** 
public double stock2(int Botao1Preco) {
    try {
        String sql = "SELECT precoproduto FROM stocks WHERE id=" +Botao1Preco; 
        ResultSet rs = statement.executeQuery(sql);
        if (rs.next()) {
            double precoprod = rs.getDouble("precoproduto");
            return precoprod;
        } else {
        	JOptionPane.showMessageDialog(null, "Preço do produto não encontrado");
        }
        rs.close();
    } catch (SQLException e) {
        System.out.println("Botão não Configurado: " + e.getMessage());
    } 
    return 0.0; // retorna um valor padrão se não encontrar nada
}

//**********************Insere stock na base de dados ******************
public void inserirprodutos(String nomeproduto, String precoproduto,double IVA)
{
	try{
		String query = "INSERT INTO stocks (nomeproduto,precoproduto,IVA) VALUES ('" + nomeproduto + "','" + precoproduto + "','" + IVA +  "')";
		this.statement.executeUpdate(query);
	
	}catch(Exception e) {
		
			   System.out.println("erro: " + e.getMessage());
		   }
}

//********************** Pega no ID do produto e altera os dados pedidos ********************
public void updateFun(String id, String nomeproduto, String precoproduto, double IVA) {
    try {
        String query = "UPDATE stocks SET nomeproduto=?, precoproduto=?, IVA=? WHERE id=?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setString(1, nomeproduto);
        statement.setString(2, precoproduto);
        statement.setDouble(3, IVA);       
        statement.setString(4, id);
        int rowsUpdated = statement.executeUpdate();
        if (rowsUpdated > 0) {
            JOptionPane.showMessageDialog(null, "Artigo atualizado com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Nenhum registo encontrado com o ID fornecido.");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Erro ao atualizar registo: " + e.getMessage());
    }
}


//**********************Visualizar Tabela dados Stocks*********************
public DefaultTableModel exibirTabela() {
    jdbccafe cafe = new jdbccafe();
    cafe.conectar();
   
    DefaultTableModel modelo2 = new DefaultTableModel();
    if (cafe.estaconectado()) {
        try {
            String sql = "SELECT * FROM stocks";
            cafe.resultset = cafe.statement.executeQuery(sql);
            modelo2.addColumn("ID");
            modelo2.addColumn("Nome do Produto");
            modelo2.addColumn("Preço do Produto");
            modelo2.addColumn("IVA");          
            while (cafe.resultset.next()) {
                Object[] registo1 = new Object[4];
                registo1[0] = cafe.resultset.getInt("id");
                registo1[1] = cafe.resultset.getString("nomeproduto");
                registo1[2] = cafe.resultset.getString("precoproduto");
                registo1[3] = cafe.resultset.getInt("IVA");                
                modelo2.addRow(registo1);
            }
        } catch (SQLException f) {
            f.printStackTrace();
        } finally {
            cafe.logout();
        }
    } else {
        System.out.println("Não foi possível conectar ao BD");
    }
    return modelo2;
}

//**********************Void Fatura ******************
public void voidfatura(String id)

{ try {
    String sql = "SELECT * FROM fatura WHERE id=" + id; 
    ResultSet rs = statement.executeQuery(sql);
    if (rs.next()) {
    	 String Nome = rs.getString("Nome");
         String NIF = rs.getString("NIF");
         String Data_Fatura = rs.getString("Data_Fatura");
         String Pagamento = rs.getString("Pagamento")+("(Void FT "+id+")");
         double Total_Fatura = Double.parseDouble(rs.getString("Total_Fatura").replace(',', '.')) * -1;
         double IVA = Double.parseDouble(rs.getString("IVA").replace(',', '.')) * -1;
         String query = "INSERT INTO fatura (Nome, NIF, IVA, Total_Fatura, Data_Fatura, Pagamento) VALUES ('" + Nome + "', '" + NIF + "', '" + IVA + "', '" + Total_Fatura + "', '" + Data_Fatura + "', '" + Pagamento + "')";
         statement.executeUpdate(query);
    }
} catch (SQLException g) {
    g.printStackTrace();
}
}


//***********Visualizar tabela de Faturas ***************

public DefaultTableModel exibirFaturas(String input) {	
    jdbccafe cafe = new jdbccafe();
    cafe.conectar();
    DefaultTableModel modelo = new DefaultTableModel();
    if (cafe.estaconectado()) {
    	try {
    		int id = -1;
            modelo.setRowCount(0);
            String sql = "SELECT * FROM fatura";
            if (input != null && !input.isEmpty()) {id = Integer.parseInt(input);  }
            if (id != -1) {sql += " WHERE id = " + id;}            
            resultset = statement.executeQuery(sql);
            modelo.addColumn("ID");
            modelo.addColumn("Nome");
            modelo.addColumn("NIF");
            modelo.addColumn("IVA");
            modelo.addColumn("Total_Fatura");
            modelo.addColumn("Data_Fatura");
            modelo.addColumn("Pagamento");
            if (resultset != null) {
                while (resultset.next()) {
                    Object[] registo = new Object[7];
                    registo[0] = resultset.getInt("id");
                    registo[1] = resultset.getString("Nome");
                    registo[2] = resultset.getString("NIF");
                    registo[3] = resultset.getString("IVA");
                    registo[4] = resultset.getString("Total_Fatura");
                    registo[5] = resultset.getString("Data_Fatura");
                    registo[6] = resultset.getString("Pagamento");
                    modelo.addRow(registo);                                
                    if (registo[6].toString().contains("Void FT")) {
                        for (int i = 0; i < 7; i++) {
                            modelo.setValueAt("<html><font color='red'>" + registo[i] + "</font></html>", modelo.getRowCount() - 1, i);
                            }
                        }
                }

            }
        } catch (SQLException e) {e.printStackTrace(); } 
    	finally {logout();}
    }
    return modelo;
}





}



 